// RootStackParams.ts
export type RootStackParamList = {
    mainscreen: undefined;
    firstaidcourse: undefined;
    calculatetotalfees: undefined;
    childmindingcourse: undefined;
    contactdetails: undefined;
    gardenmaintenancecourse: undefined;
    landscapingcourse: undefined;
    cookingcourse: undefined;
    lifeskillcourse: undefined;
    sewingcourse: undefined;
    summaryofsixmonthscourse: undefined;
    summaryofsixweekscourse: undefined;
};
